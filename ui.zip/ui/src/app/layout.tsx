import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Fireline | Robot Control",
  description: "Live telemetry and operator controls for a fire-response robot.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
